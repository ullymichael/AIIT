/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ue01;

import java.util.*;



/**
 *
 * @author micha
 */
public class SpritUI {

    public SpritUI() {
        eingabe();
        rechnen();
        ausgabe();
    }
    
    private void eingabe()
    {
        System.out.println("Spritverbrauchsrechnung");
        System.out.println("=======================");
        System.out.println("");
        //Eingabe
        Scanner scanner = new Scanner(System.in);
        //Eingabe gefahren km
        System.out.print("Gefahrene km: ");
        
    }
    
    private void rechnen()
    {
        
    }
    
    private void ausgabe()
    {
        
    }
}
