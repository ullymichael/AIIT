/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ue00; //package-anweisung

/**
 *
 * @author micha
 */
public class MeineErsteJavaKlasse 
{   //main Methode: automatisch erstellen: psvm schreiben dann tabulator)
    //Um eine Klasse starten zu können brauche ich eine Main-Methode.
    public static void main(String[] args) 
    {
        //sout * Tab
        System.out.println("Hello Java World");
    }
}
